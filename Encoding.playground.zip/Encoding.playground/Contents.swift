import Cocoa
import Foundation

var greeting = "Hello, playground"

class iOS_SDP: Codable{
    var hostInstitute: String
    var cohort: String
    var size: Int
    
    init(hostInstitute: String, cohort: String, size: Int) {
        self.hostInstitute = hostInstitute
        self.cohort = cohort
        self.size = size
    }
}
var mitiOSSDP = iOS_SDP(hostInstitute: "MIT", cohort: "2025", size: 100)
var jsonEncoder = JSONEncoder()
if let data = try? jsonEncoder.encode(mitiOSSDP) {
    if let json = String(data: data, encoding: .utf8) {
        print(json)
    }
}
