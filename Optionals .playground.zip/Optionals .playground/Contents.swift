import Cocoa

var greeting = "Hello, playground"

//struct Student {
//    var name: String
//    var enrollmentYear: Int//expecting intiger
//}
//
//let firstStudent = Student(name:"Nevin", enrollmentYear:2023)
//let secondStudent = Student(name:"Sejal", enrollmentYear:nil)
// here enrollmentYear won't take nil, you'll get compile time error
// to overcome this use "?"
// as you can see bellow

struct Student {
    var name: String
    var enrollmentYear: Int? // optional intiger
}

let firstStudent = Student(name:"Nevin", enrollmentYear:2023)
let secondStudent = Student(name:"Sejal", enrollmentYear:nil)

//var serverCode = nil -> throws errors
// ways to define it
var serverCode: Int? = nil
var serverCode1: Int? = 402
// here type anotation is compulsuray
var serverCode2: Int? // even here without mentioning nil, it takes it as a nil

// force-unwrap -> this value will be unwrappeed and there will be a value for it

if firstStudent.enrollmentYear != nil {
    let actualYear = firstStudent.enrollmentYear!
    print("Enrollment in \(actualYear)")
}
//let unwrappedYear = secondStudent.enrollmentYear!
//__lldb_expr_188/Optionals .playground:37: Fatal error: Unexpectedly found nil while unwrapping an Optional value
let unwrappedYear = secondStudent.enrollmentYear

// optional binding (better than force unwrapped)
// starts with if let
// this is a good way of handling nil and your app won't get crahsed
// in the above way, the app will crash
// use this way while creating a app
if let unwrappedYear1 = secondStudent.enrollmentYear {
    print("Enrollment in \(unwrappedYear1)")
} else {
    print("Not enrolled yet")
}



//
//let string = "123"
//let possibleNumber = Int(string)
//print (possibleNumber)
// output : Optional(123)


let string1 = "123"
let possibleNumber2 = Int(string1)
print (possibleNumber2!)
// output:123


if let number = possibleNumber2 {
    print("Converted number: \(number)")
} else {
    print("Couldn't convert to Int")
}
// output:Converted number: 123

func fullName(firstName: String, middleName: String?, lastName: String){
    if let middleName = middleName {
        print("\(firstName) \(middleName) \(lastName)")
    } else {
        print("\(firstName) \(lastName)")
    }
}

//fullName(firstName: "Nevin",middleName: "Sajan", lastName: "Abraham")
//@MainActor
//func getURL(_ string:String) -> String? {
//    if let url = URL(string:string) , UIApplication.shared.canOpenURL(url){
//        return "\(url)"
//    } else {
//        return nil
//    }
//}
//let urlString = "http://www.apple.com"
//if let url =  getURL(urlString){
//    print(url)
//} else {
//    print("Invalid URl")
//}

struct Toddler {
    var birthName: String
    var monthsOld: Int
    
    init?(birthName:String, monthsOld:Int) {
        if monthsOld < 12 || monthsOld > 36 {
            return nil
        } else {
            self.birthName = birthName
            self.monthsOld = monthsOld
            
        }
    }
}
if let ababy = Toddler(birthName: "Nevin", monthsOld: 16){
    print(ababy)
} else {
    print("Not a Toddler")
}

// optional chaining
struct Person {
    var age : Int
    var residence: Residence?
}

struct Residence {
    var address:Address?
}

struct Address {
    let buildingNumber:String?
    let streetName: String?
    let Appartment:Int?
}

let aPerson = Person(age:15, residence:Residence(address:(Address(buildingNumber:"Vyas", streetName: "Kothurd", Appartment: 7))))
print(aPerson)

if let theResidence = aPerson.residence {
    if let theAddress = theResidence.address{
        if let theAppartmentNumber = theAddress.Appartment{
            print("They live in appartment number \(theAppartmentNumber)")
        }
    }
}
