import Cocoa
import Foundation

protocol messanger{
    func passData(_ data: String)
}
class firstView_reciver:messanger{
    func passData(_ data: String) {
        print("The data That is recived is : \(data)")
    }
}
class secondView_Sender{
    var delegate:messanger?
    func sendData(_ data:String){
        delegate?.passData(data)
    }
}
var firstView = firstView_reciver()
var secondView = secondView_Sender()
secondView.delegate = firstView// initialised the delegate
secondView.sendData("Hello World")

protocol myProtocol{
    
}
