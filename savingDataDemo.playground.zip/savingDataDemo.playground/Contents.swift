import Cocoa

struct Note: Codable {
    let title: String
    let text: String
    let timestamp: String
}

let note1 = Note(title: "Note One", text: "Sample Note", timestamp: "Ok")
let note2 = Note(title: "Note Two", text: "Another Sample Note", timestamp: "Ok")
let note3 = Note(title: "Note Three", text: "Yet Another Sample Note", timestamp: "OK")

let note = [note1, note2, note3]

let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!// in which directory the url is going to be stored

let archiveURL = documentDirectory.appendingPathComponent("notes_test").appendingPathExtension("plist")//

let propertyListEncoder = PropertyListEncoder()
if let encodedNote = try? propertyListEncoder.encode(note) {
    print("Encoded Note : \(encodedNote)")
    
    try? encodedNote.write(to: archiveURL, options: .noFileProtection)
    
    let propertyListDecoder = PropertyListDecoder()
    if let decodedNote = try? propertyListDecoder.decode([Note].self, from: encodedNote) {
        print("Decoded Note : \(decodedNote)")
    }
}

print("Document Directory : \(documentDirectory)")
print("Archive URL: \(archiveURL)")
