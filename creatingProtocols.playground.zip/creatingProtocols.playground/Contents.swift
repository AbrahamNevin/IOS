import Cocoa

var greeting = "Hello, playground"

protocol FullyNames {
    var fullName: String { get }
    func sayFullName()
}
struct Person: FullyNames {
    func sayFullName() {
            
    }
    
    var fullName: String
    var lastName: String
    }

